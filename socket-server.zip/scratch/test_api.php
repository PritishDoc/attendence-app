<?php
$_SERVER['REQUEST_METHOD'] = 'POST';
$_SERVER['REQUEST_URI'] = '/api/tracking/log';
$_SERVER['HTTP_AUTHORIZATION'] = ''; // I need a valid token to bypass auth.

// But wait, it's easier to just mock the JWT token.
require 'api/config/constants.php';
require 'api/helpers/jwt.php';
$token = generateJWT(8, 'employee', 2);
$_SERVER['HTTP_AUTHORIZATION'] = 'Bearer ' . $token;

$body = json_encode([
    'latitude' => 20.25,
    'longitude' => 85.79,
    'accuracy' => 10,
    'speed' => 0
]);
file_put_contents('php://temp', $body);
// Wait, file_get_contents('php://input') can't be easily mocked in a script.
// It's better to just use curl, but curl timed out previously.
