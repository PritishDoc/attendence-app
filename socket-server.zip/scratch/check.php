<?php
require 'api/config/database.php';
$db = Database::getInstance()->getConnection();
$att = $db->query('SELECT * FROM attendance')->fetchAll(PDO::FETCH_ASSOC);
$trk = $db->query('SELECT * FROM live_tracking')->fetchAll(PDO::FETCH_ASSOC);
echo "Attendance:\n";
print_r($att);
echo "\nLive Tracking:\n";
print_r($trk);
