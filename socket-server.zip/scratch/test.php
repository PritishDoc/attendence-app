<?php
require 'api/config/constants.php';
require 'api/helpers/jwt.php';

$token = JWT::generate([
    'user_id' => 2,
    'role' => 'company_admin',
    'company_id' => 2
]);

$options = [
    'http' => [
        'header'  => "Content-type: application/json\r\nAuthorization: Bearer $token\r\n",
        'method'  => 'GET',
        'ignore_errors' => true
    ]
];
$context  = stream_context_create($options);
$result = file_get_contents('http://localhost:8000/api/tracking/active', false, $context);

echo "HTTP response:\n$http_response_header[0]\n";
echo "Response body:\n$result\n";
