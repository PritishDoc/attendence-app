<?php
require 'api/config/database.php';
$db = Database::getInstance()->getConnection();
$stmt = $db->query('SELECT * FROM branches');
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
