<?php
require 'api/config/constants.php';
require 'api/config/database.php';
require 'api/helpers/response.php';
require 'api/models/Branch.php';

$branchModel = new Branch();
try {
    $id = $branchModel->create(['company_id'=>1, 'name'=>'Head Office', 'location'=>'Bhubaneswar', 'status'=>'active']);
    Response::success($branchModel->findById($id), 'Branch created successfully', 201);
} catch (PDOException $e) {
    if (strpos($e->getMessage(), 'unique_branch') !== false) {
        Response::error('A branch with this name already exists for the company', 409);
    }
    throw $e;
}
