<?php
require_once __DIR__ . '/../api/config/database.php';

try {
    $db = Database::getInstance()->getConnection();
    
    // 1. Create leaves table
    $sql1 = "
    CREATE TABLE IF NOT EXISTS leaves (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        company_id INT NOT NULL,
        leave_type ENUM('CL', 'SL', 'CO', 'LOP', 'EL', 'ML') NOT NULL,
        leave_duration ENUM('full_day', 'half_day_start', 'half_day_end') DEFAULT 'full_day',
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        reason TEXT,
        status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
        approved_by INT NULL,
        approved_at TIMESTAMP NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (employee_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
        FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL
    );
    ";
    $db->exec($sql1);
    echo "Created leaves table.\n";

    // 2. Add index on leaves
    try {
        $db->exec("CREATE INDEX idx_leave_employee ON leaves(employee_id, start_date, end_date);");
        echo "Created index on leaves.\n";
    } catch (PDOException $e) {
        // Might already exist if script run multiple times
        echo "Index on leaves might exist: " . $e->getMessage() . "\n";
    }

    // 3. Alter attendance table status
    $sql2 = "ALTER TABLE attendance MODIFY COLUMN status ENUM('present', 'absent', 'late', 'half_day', 'leave', 'wfh', 'outdoor') DEFAULT 'present';";
    $db->exec($sql2);
    echo "Altered attendance table status column.\n";

    // 4. Add index on attendance
    try {
        $db->exec("CREATE INDEX idx_attendance_employee_date ON attendance(employee_id, date);");
        echo "Created index on attendance.\n";
    } catch (PDOException $e) {
        echo "Index on attendance might exist: " . $e->getMessage() . "\n";
    }
    
    echo "All database updates completed successfully.\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
