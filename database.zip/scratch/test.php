<?php
require_once __DIR__ . '/../api/config/constants.php';
require_once __DIR__ . '/../api/config/database.php';
require_once __DIR__ . '/../api/helpers/jwt.php';
require_once __DIR__ . '/../api/models/User.php';

// Create a dummy token for test
$accessToken = JWT::generate([
    'user_id' => 1,
    'company_id' => 1,
    'role' => 'company_admin',
    'email' => 'admin@demo.com',
    'type' => 'access'
], JWT_EXPIRY);

$refreshToken = JWT::generate([
    'user_id' => 1,
    'type' => 'refresh',
    'absolute_exp' => time() + JWT_ABSOLUTE_EXPIRY
], JWT_REFRESH_EXPIRY);

echo "Token generated.\n";

$payload = JWT::verify($refreshToken);
if (!$payload) {
    echo "Verify failed.\n";
    exit;
}

$userModel = new User();
$user = $userModel->findById($payload['user_id']);
if (!$user) {
    echo "User not found.\n";
    exit;
}

echo "User found: " . $user['email'] . "\n";

// Emulate logic
if (!$user['refresh_token_hash'] || !password_verify($refreshToken, $user['refresh_token_hash'])) {
    echo "Token Reuse Attack Detected!\n";
} else {
    echo "Token valid.\n";
}

try {
    $userModel->update($user['id'], [
        'refresh_token_hash' => password_hash($refreshToken, PASSWORD_BCRYPT),
        'previous_refresh_token_hash' => null,
        'grace_period_expires_at' => null
    ]);
    echo "Update successful.\n";
} catch (Exception $e) {
    echo "Update failed: " . $e->getMessage() . "\n";
}
