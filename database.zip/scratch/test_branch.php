<?php
require 'api/config/database.php';
require 'api/models/Branch.php';
$b = new Branch();
try {
    $id = $b->create(['company_id'=>1, 'name'=>'Head Office 2', 'location'=>'Bhubaneswar', 'status'=>'Active']);
    echo "Success ID: $id";
} catch(Exception $e) {
    echo $e->getMessage();
}
