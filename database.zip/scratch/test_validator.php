<?php
require 'api/config/constants.php';
require 'api/config/database.php';
require 'api/helpers/response.php';
require 'api/helpers/validation.php';
require 'api/models/Branch.php';

$v = new Validator();
$v->required('name', 'New Branch')->length('name', 'New Branch', 2, 100);
$v->validate();

echo "Validator passes!\n";
